# patterns
## pattern description:
- Design the workflow of each pattern in the Symbols and Numbers, Alphabets, design There is a typical structure to print any pattern, i.e., the number of rows and columns. We need to use two loops to print any pattern, i.e., use nested loops. The outer loop tells us the number of rows, and the inner loop tells us the column needed to print the pattern.Accept the number of rows from a user using the input() function to decide the size of a pattern.
You can use
[Github-flavored Markdown](https://github.com/yaminipendyala/patterns)
to write your content.